export const v1_base_url = "hianimez.to";
