export const v3_base_url = "aniplay.lol";
