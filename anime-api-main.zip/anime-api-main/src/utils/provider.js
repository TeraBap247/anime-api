export const provider = "https://megacloud.tv";
