export const PLAYER_SCRIPT_URL =
  "https://megacloud.tv/js/player/a/e1-player.min.js";
